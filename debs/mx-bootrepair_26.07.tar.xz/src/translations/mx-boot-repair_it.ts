<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="it">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>MX Ripara Boot</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation>MX Ripara Boot è un utility che può servire per reinstallare GRUB sulla Partizione di Sistema EFI (ESP), sul Registro di Inizializzazione del Disco (MBR) o sul Registro di Inizializzazione della Partizione root (PBR). Permette di riscrivere il file di configurazione di GRUB, fare il back up e ripristinare MBR o PBR.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>Cosa vorresti fare?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>Fare il backup dell&apos; MBR o del PBR (solo per legacy boot)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>Reinstallare il gestore del boot GRUB su ESP, MBR o PBR (root)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>Riparare il file di configurazione di GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>Ripristinare MBR o PBR dal backup (solo per legacy boot)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="631"/>
        <source>Select Boot Method</source>
        <translation>Selezionare il modo di avvio Boot</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="410"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="632"/>
        <source>Location:</source>
        <translation>Posizione:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation>EFI System Partition</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation>Root (Partition Boot Record)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="634"/>
        <source>root</source>
        <translation>root</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="639"/>
        <source>Select root location:</source>
        <translation>Seleziona la posizione di root:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="633"/>
        <source>Install on:</source>
        <translation>Installa su:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="333"/>
        <source>Output</source>
        <translation>Output</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="401"/>
        <source>About this application</source>
        <translation>Informazioni su questa applicazione</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="404"/>
        <source>About...</source>
        <translation>Info...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="452"/>
        <source>Display help </source>
        <translation>Visualizza la guida</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="455"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="461"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="502"/>
        <source>Cancel any changes then quit</source>
        <translation>Cancella tutte le modifiche ed esci</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="505"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="511"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="530"/>
        <source>Apply any changes</source>
        <translation>Applica tutti i cambiamenti</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="533"/>
        <location filename="../src/gui/mainwindow.cpp" line="161"/>
        <source>Next</source>
        <translation>Successivo</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="667"/>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="236"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>GRUB è in fase d&apos;installazione sulla periferica %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="176"/>
        <location filename="../src/gui/mainwindow.cpp" line="528"/>
        <source>Authorization Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="176"/>
        <location filename="../src/gui/mainwindow.cpp" line="529"/>
        <source>Could not obtain administrator privileges.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="211"/>
        <location filename="../src/gui/mainwindow.cpp" line="276"/>
        <location filename="../src/gui/mainwindow.cpp" line="331"/>
        <location filename="../src/gui/mainwindow.cpp" line="451"/>
        <location filename="../src/gui/mainwindow.cpp" line="672"/>
        <location filename="../src/gui/mainwindow.cpp" line="676"/>
        <location filename="../src/gui/mainwindow.cpp" line="683"/>
        <location filename="../src/gui/mainwindow.cpp" line="689"/>
        <location filename="../src/gui/mainwindow.cpp" line="697"/>
        <location filename="../src/gui/mainwindow.cpp" line="704"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="212"/>
        <location filename="../src/gui/mainwindow.cpp" line="277"/>
        <location filename="../src/gui/mainwindow.cpp" line="332"/>
        <source>Could not unlock %1. Please check the password and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="295"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>Il file di configurazione di GRUB (grub.cfg) viene ricostituito.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="346"/>
        <source>Generating initramfs images on: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="362"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>Backup dell&apos; MBR o del PBR dall&apos;unità %1.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="419"/>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="420"/>
        <source>You are going to write the content of </source>
        <translation>Stai per scrivere il contenuto di</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="420"/>
        <source> to </source>
        <translation>su</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="421"/>
        <source>

Are you sure?</source>
        <translation>

Sei sicuro?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="427"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>Ripristino dell&apos; MBR/PBR da backup sull&apos;unità %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="452"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>Non si riesce a trovare EFI system partition (ESP) su un qualsiasi disco di sistema. Prego, create un ESP e provate ancora.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="476"/>
        <source>Select %1 location:</source>
        <translation>Seleziona %1 posizione:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="521"/>
        <source>Success</source>
        <translation>Operazione riuscita</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="521"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation>Processo ultimato con successo.&lt;p&gt;&lt;b&gt;Vuoi uscire da MX Ripara Boot?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="546"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>Processo ultimato. Sono incorsi degli errori.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="198"/>
        <location filename="../src/gui/mainwindow.cpp" line="263"/>
        <location filename="../src/gui/mainwindow.cpp" line="318"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Digita la password per sbloccare la partizione criptata:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="548"/>
        <source>Unknown error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="638"/>
        <source>Select GRUB location</source>
        <translation>Seleziona la posizione di GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="647"/>
        <source>Select initramfs options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="657"/>
        <source>Select Item to Back Up</source>
        <translation>Seleziona l&apos;elemento da sottoporre a backup</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="662"/>
        <source>Select Item to Restore</source>
        <translation>Seleziona l&apos;elemento da ripristinare</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="672"/>
        <location filename="../src/gui/mainwindow.cpp" line="683"/>
        <source>No location was selected.</source>
        <translation>Non è stata selezionata nessuna posizione.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="677"/>
        <location filename="../src/gui/mainwindow.cpp" line="690"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation>Seleziona la partizione di root del sistema che vuoi correggere.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="695"/>
        <source>Select backup file name</source>
        <translation>Scegli un nome per il file di backup</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="697"/>
        <location filename="../src/gui/mainwindow.cpp" line="704"/>
        <source>No file was selected.</source>
        <translation>Nessun file è stato scelto</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="702"/>
        <source>Select MBR or PBR backup file</source>
        <translation>Scegli il file di backup di MBR o PBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="720"/>
        <source>About %1</source>
        <translation>Circa %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="722"/>
        <source>Version: </source>
        <translation>Versione: </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="723"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation>Programma di MX Linux per la riparazione del boot, di facile uso</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="725"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="726"/>
        <source>%1 License</source>
        <translation>%1 Licenza</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="737"/>
        <source>%1 Help</source>
        <translation>%1 Aiuto</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="54"/>
        <location filename="../src/gui/about.cpp" line="59"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="116"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="117"/>
        <location filename="../src/gui/about.cpp" line="127"/>
        <source>Changelog</source>
        <translation>Registro delle modifiche</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="118"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="31"/>
        <location filename="../src/gui/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="84"/>
        <source>MX Boot Repair</source>
        <translation>MX Ripara Boot</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="92"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="97"/>
        <source>Force CLI mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="98"/>
        <source>Print actions without executing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Do not prompt; require flags</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Target for install: mbr, esp, root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Path for backup/restore image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Skip confirmations (for restore)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Enable verbose output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Suppress non-error output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="119"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="125"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="126"/>
        <source>You must run this program with admin access.</source>
        <translation>Devi eseguire questo programma come amministratore.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>sì</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>