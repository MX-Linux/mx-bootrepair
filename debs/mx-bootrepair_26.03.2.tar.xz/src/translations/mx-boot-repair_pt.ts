<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>MX Reparador do Arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation>O MX Reparador do Arranque é um utilitário que pode ser usado para reinstalar o carregador do arranque GRUB na ESP (EFI Sistema Partition), no MBR (Master Boot Record) do disco ou no PBR (Partition Boot Record) da partição raiz ( / , root), para reconstruir o ficheiro de configuração do GRUB, para fazer cópias de segurança do MBR ou do PBR, ou para restaurar o MBR ou o PBR.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>O que fazer?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>Cópia de segurança do MBR ou do PBR (apenas em computadores com BIOS)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>Reinstalar o carregador do arranque GRUB em ESP, MBR ou PBR (root)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>Refazer o ficheiro de configuração do GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation>Regenerar imagens do initramfs</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>Restaurar MBR ou PBR a partir de cópia (apenas em computadores com BIOS)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="585"/>
        <source>Select Boot Method</source>
        <translation>Dados para instalação do Arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="410"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="586"/>
        <source>Location:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation>Partição de Sistema EFI</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation>Raíz (Partition Boot Record)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="588"/>
        <source>root</source>
        <translation>PBR (da partição raíz)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="593"/>
        <source>Select root location:</source>
        <translation>Seleccionar a localização da raiz ( / , root):</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="587"/>
        <source>Install on:</source>
        <translation>Instalar em:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="333"/>
        <source>Output</source>
        <translation>Resultado</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="401"/>
        <source>About this application</source>
        <translation>Sobre esta aplicação</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="404"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="452"/>
        <source>Display help </source>
        <translation>Mostrar ajuda</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="455"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="461"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="502"/>
        <source>Cancel any changes then quit</source>
        <translation>Cancelar alterações e sair</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="505"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="511"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="530"/>
        <source>Apply any changes</source>
        <translation>Aplicar alterações</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="533"/>
        <location filename="../src/gui/mainwindow.cpp" line="140"/>
        <source>Next</source>
        <translation>Seguinte</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="621"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="214"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>O GRUB está a ser instalado em %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="155"/>
        <location filename="../src/gui/mainwindow.cpp" line="498"/>
        <source>Authorization Failed</source>
        <translation>Falha de autorização</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="155"/>
        <location filename="../src/gui/mainwindow.cpp" line="499"/>
        <source>Could not obtain administrator privileges.</source>
        <translation>Foi impossível obter permissões de administrador.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="189"/>
        <location filename="../src/gui/mainwindow.cpp" line="251"/>
        <location filename="../src/gui/mainwindow.cpp" line="303"/>
        <location filename="../src/gui/mainwindow.cpp" line="421"/>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <location filename="../src/gui/mainwindow.cpp" line="626"/>
        <location filename="../src/gui/mainwindow.cpp" line="630"/>
        <location filename="../src/gui/mainwindow.cpp" line="637"/>
        <location filename="../src/gui/mainwindow.cpp" line="643"/>
        <location filename="../src/gui/mainwindow.cpp" line="651"/>
        <location filename="../src/gui/mainwindow.cpp" line="658"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="190"/>
        <location filename="../src/gui/mainwindow.cpp" line="252"/>
        <location filename="../src/gui/mainwindow.cpp" line="304"/>
        <source>Could not unlock %1. Please check the password and try again.</source>
        <translation>Foi impossível desbloquear %1. Verifique a senha e tente novamente.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="270"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>O ficheiro de configuração do GRUB (grub.cfg) está a ser refeito.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="318"/>
        <source>Generating initramfs images on: %1</source>
        <translation>A gerar imagens initramfs em %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="332"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>A guardar o MBR/PBR de %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="389"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="390"/>
        <source>You are going to write the content of </source>
        <translation>Vai ser escrito o conteúdo de </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="390"/>
        <source> to </source>
        <translation> em </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="391"/>
        <source>

Are you sure?</source>
        <translation>
    
Seguramente?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="397"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>A restaurar o MBR/PBR em %1 a partir da cópia.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="422"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>Não foi encontrada qualquer ESP (EFI System Partition). Criar uma partição ESP e voltar a tentar.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="446"/>
        <source>Select %1 location:</source>
        <translation>Seleccionar a localização de %1:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="473"/>
        <source>Back</source>
        <translation>Voltar atrás</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="491"/>
        <source>Success</source>
        <translation>Êxito</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="491"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation>O processo terminou com êxito.&lt;p&gt;&lt;b&gt;Sair do MX Reparador do Arranque?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>O processo terminou. Ocorreram erros.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="177"/>
        <location filename="../src/gui/mainwindow.cpp" line="239"/>
        <location filename="../src/gui/mainwindow.cpp" line="291"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Introduzir a senha para desbloquear a partição encriptada %1:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="592"/>
        <source>Select GRUB location</source>
        <translation>Seleccionar a localização do GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="601"/>
        <source>Select initramfs options</source>
        <translation>Selecione as opções do initramfs</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="611"/>
        <source>Select Item to Back Up</source>
        <translation>Seleccionar o item a Copiar para Segurança</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="616"/>
        <source>Select Item to Restore</source>
        <translation>Seleccionar o item a Restaurar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="626"/>
        <location filename="../src/gui/mainwindow.cpp" line="637"/>
        <source>No location was selected.</source>
        <translation>Nenhum local foi escolhido.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="631"/>
        <location filename="../src/gui/mainwindow.cpp" line="644"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation>Por favor, selecione a partição root do sistema que deseja reparar.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="649"/>
        <source>Select backup file name</source>
        <translation>Escolher o nome da cópia de segurança.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="651"/>
        <location filename="../src/gui/mainwindow.cpp" line="658"/>
        <source>No file was selected.</source>
        <translation>Não foi seleccionado qualquer ficheiro.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="656"/>
        <source>Select MBR or PBR backup file</source>
        <translation>Seleccionar cópia de segurança do MBR ou do PBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="674"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="676"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="677"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation>Programa simples de reparação do arranque para o MX</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="679"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="680"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="691"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="53"/>
        <location filename="../src/gui/about.cpp" line="58"/>
        <source>Could not load %1</source>
        <translation>Foi impossível carregar %1</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="81"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="82"/>
        <location filename="../src/gui/about.cpp" line="92"/>
        <source>Changelog</source>
        <translation>Registo de alterações</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="83"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="104"/>
        <source>Could not load changelog.</source>
        <translation>Falha ao carregar registo de alterações.</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="30"/>
        <location filename="../src/gui/about.cpp" line="107"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="84"/>
        <source>MX Boot Repair</source>
        <translation>MX-Reparador do Arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="92"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation>MX Boot Repair - programa por interface gráfica e por interface de linha de comandos para reparar o bootloader GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="97"/>
        <source>Force CLI mode</source>
        <translation>Forçar o Modo por Linha de Comandos</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="98"/>
        <source>Print actions without executing</source>
        <translation>Exibir as ações sem executá-las</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Do not prompt; require flags</source>
        <translation>Não solicitar, somente requerer as flags</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation>Ação: instalar, reparar, cópia de segurança, restaurar, initramfs</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Target for install: mbr, esp, root</source>
        <translation>Alvo da instalação: MBR, ESP, Root</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation>Destino da instalação (ex: sda, sda1)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation>Partição de ‘root’ (raiz), por ex.  /dev/sda2</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation>Partição para montar em /boot no chroot</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation>Partição para montar em /boot/efi do chroot</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Path for backup/restore image</source>
        <translation>Caminho da cópia de segurança ou restauro da imagem</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Skip confirmations (for restore)</source>
        <translation>Não fazer perguntas de confirmação (no restauro)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Enable verbose output</source>
        <translation>Ativar output detalhado</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Suppress non-error output</source>
        <translation>Não exibir nada quando não ocorrerem erros</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="119"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation>Erro: As opções ‘--verbose’ e ‘--quiet’ não podem ser utilizadas ao mesmo tempo
</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="125"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="126"/>
        <source>You must run this program with admin access.</source>
        <translation>Deve executar este programa como administrador.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation>O índice inválido. Tente novamente: </translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation>A seleção inválida. Insira um número</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation>MX Boot Repair (CLI)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation>1) Instalar o GRUB</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation>2) Reparar o GRUB (update-grub)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation>3) Regenerar o initramfs</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation>4) Fazer a cópia de segurança do MBR ou do PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation>5) Restaurar o MBR ou o PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation>q) Sair</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation>Selecione a ação [1 a 5 ou ‘q’ para sair}: </translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation>Seleção inválida. Pressione 1 a 5 ou ‘q’ para sair.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation>Alvot: 0) MBR  1) ESP  2) Root</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation>  [detetado: UEFI]</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation>  [detectado: BIOS Legada]</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation>Escolha o alvo</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation>Nenhuma partição foi encontrada. A voltar ao menu principal.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation>Nenhum disco foi encontrado. A voltar para o menu principal.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation>Selecione o disco para o MBR (ex: sda)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation>Selecione a partição para o GRUB (ex; sda1)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation>Escolha a partição root do sistema instalado</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation>Escolha a partição root a reparar</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation>Escolha a partição root a regenerar o initramfs</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation>Selecione o disco para onde fazer a cópia de segurança do MBR ou do PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation>Insira o caminho do ficheiro de saída (ou pressione ‘b’ para voltar ou ‘q’ para sair): </translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation>Selecione o disco para onde restaurar o MBR ou o PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation>Indique o caminho para a cópia de segurança (ou ‘b’ para voltar, ‘q’ para sair): </translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation>AVISO: Isto irá substituir os primeiros 446 bytes de /dev/</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation>. Você quer continuar? [s/N]: </translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>sim</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation>Cancelado.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation>Escolha desconhecida</translation>
    </message>
</context>
</TS>