<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fil_PH">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>Ano ang gusto mong gawin?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>I-backup ang MBR o PBR (pang legacy boot lang)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>Muling i-install ang GRUB bootloader sa ESP, MBR o PBR (root)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>Kumupunihin ang  configuration ng file ng GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>Isauli ang MBR o PBR mula sa backup (pang legacy boot lang)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="441"/>
        <source>Select Boot Method</source>
        <translation>Pumili ng paraan ng pag Boot</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation>Pangunahing Record ng Boot</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="398"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="442"/>
        <source>Location:</source>
        <translation>Lugar:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation> Sistema ng Partition ng EFI</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation>Root (Pagkakahati ng Record ng Boot)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="444"/>
        <source>root</source>
        <translation>root</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="449"/>
        <source>Select root location:</source>
        <translation>Pumili ng lugar ng root:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="443"/>
        <source>Install on:</source>
        <translation>I-install sa:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="389"/>
        <source>About this application</source>
        <translation>Patungkol sa application na ito</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="392"/>
        <source>About...</source>
        <translation>Patungkol sa...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="440"/>
        <source>Display help </source>
        <translation>Maghanap ng tulong</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="443"/>
        <source>Help</source>
        <translation>Tulong</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="449"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="490"/>
        <source>Cancel any changes then quit</source>
        <translation>Huwag tanggapin ang mga binago at lumabas na</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="493"/>
        <source>Cancel</source>
        <translation>Huwag ituloy</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="499"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="518"/>
        <source>Apply any changes</source>
        <translation>Tanggapin ang alinmang binago</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="521"/>
        <location filename="../src/gui/mainwindow.cpp" line="87"/>
        <source>Next</source>
        <translation>Kasunod</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="477"/>
        <source>Apply</source>
        <translation>Tanggapin</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="107"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>Ang GRUB ay kasalukuyang ini-install sa  device na %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="296"/>
        <location filename="../src/gui/mainwindow.cpp" line="366"/>
        <location filename="../src/gui/mainwindow.cpp" line="482"/>
        <location filename="../src/gui/mainwindow.cpp" line="486"/>
        <location filename="../src/gui/mainwindow.cpp" line="493"/>
        <location filename="../src/gui/mainwindow.cpp" line="499"/>
        <location filename="../src/gui/mainwindow.cpp" line="507"/>
        <location filename="../src/gui/mainwindow.cpp" line="514"/>
        <source>Error</source>
        <translation>May error</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="146"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>Ang configuration ng file ng GRUB  (grub.cfg) ay muling binubuo.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="180"/>
        <source>Generating initramfs images on: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="209"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>Ginagawan ng backup MBR o PBR mula sa device na %1 </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="265"/>
        <source>Warning</source>
        <translation>Babala</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="266"/>
        <source>You are going to write the content of </source>
        <translation>Susulatan mo ang laman ng </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="266"/>
        <source> to </source>
        <translation>sa</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="267"/>
        <source>

Are you sure?</source>
        <translation>

Nakakatiyak ka ba?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="273"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>Isinasauli ang MBR/PBR mula sa backup papuntang device na %1 </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="297"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>Di maaring matagpuan ang pagkakahati ng sistema ng EFI  (ESP) sa alinman mga disk. Dapat gumawa ng ESP at subuking muli</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="321"/>
        <source>Select %1 location:</source>
        <translation>Piliin ang lugar na %1 :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="344"/>
        <source>Back</source>
        <translation>Magbalik</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="360"/>
        <source>Success</source>
        <translation>Tagumpay</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="360"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="366"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>Natapos na  ang proseso. May mga errors na lumitaw.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="114"/>
        <location filename="../src/gui/mainwindow.cpp" line="154"/>
        <location filename="../src/gui/mainwindow.cpp" line="186"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Ipasok ang password para maalis ang trangka ng encrypted partition %1 :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="448"/>
        <source>Select GRUB location</source>
        <translation>Pumili ng paglalagyan ng GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="457"/>
        <source>Select initramfs options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="467"/>
        <source>Select Item to Back Up</source>
        <translation>Piliin ang item na gusto mong gawan ng backup</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="472"/>
        <source>Select Item to Restore</source>
        <translation>Piliin ang item na isasauli</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="482"/>
        <location filename="../src/gui/mainwindow.cpp" line="493"/>
        <source>No location was selected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="487"/>
        <location filename="../src/gui/mainwindow.cpp" line="500"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="505"/>
        <source>Select backup file name</source>
        <translation>Pumili ng pangalan ng backup</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="507"/>
        <location filename="../src/gui/mainwindow.cpp" line="514"/>
        <source>No file was selected.</source>
        <translation>Walang file na napili.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="512"/>
        <source>Select MBR or PBR backup file</source>
        <translation>Piliin ang MBR o PBR file na backup</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="530"/>
        <source>About %1</source>
        <translation>Patungkol sa %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="532"/>
        <source>Version: </source>
        <translation>Bersyon: </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="533"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="535"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Karapatan (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="536"/>
        <source>%1 License</source>
        <translation>%1 Pahintulot</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="549"/>
        <source>%1 Help</source>
        <translation>%1 Tulong</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="52"/>
        <source>License</source>
        <translation>Lisensya</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="53"/>
        <location filename="../src/gui/about.cpp" line="63"/>
        <source>Changelog</source>
        <translation>Ulat na mga pagbabago</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="54"/>
        <source>Cancel</source>
        <translation>Huwag ituloy</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;Isara</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="86"/>
        <source>MX Boot Repair</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="94"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Force CLI mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Print actions without executing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Do not prompt; require flags</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Target for install: mbr, esp, root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Path for backup/restore image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Skip confirmations (for restore)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="110"/>
        <source>Enable verbose output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="111"/>
        <source>Suppress non-error output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="121"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="127"/>
        <source>Error</source>
        <translation>May error</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="128"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>oo</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>