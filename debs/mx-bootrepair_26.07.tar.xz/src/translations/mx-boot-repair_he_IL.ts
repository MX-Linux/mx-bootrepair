<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="he_IL">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>תיקון האתחול של MX</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>מה ברצונך לעשות?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>תיקון קובץ ההגדרות של GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="631"/>
        <source>Select Boot Method</source>
        <translation>בחירת שיטת אתחול</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="410"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="632"/>
        <source>Location:</source>
        <translation>מיקום:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation>מחיצת מערכת EFI</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="634"/>
        <source>root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="639"/>
        <source>Select root location:</source>
        <translation>בחירת מיקום תיקיית העל:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="633"/>
        <source>Install on:</source>
        <translation>התקנה על:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="333"/>
        <source>Output</source>
        <translation>יציאה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="401"/>
        <source>About this application</source>
        <translation>על אודות יישום זה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="404"/>
        <source>About...</source>
        <translation>על אודות...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="452"/>
        <source>Display help </source>
        <translation>הצגת עזרה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="455"/>
        <source>Help</source>
        <translation>עזרה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="461"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="502"/>
        <source>Cancel any changes then quit</source>
        <translation>לבטל את כל השינויים ואז לצאת</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="505"/>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="511"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="530"/>
        <source>Apply any changes</source>
        <translation>החלת כל השינויים</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="533"/>
        <location filename="../src/gui/mainwindow.cpp" line="161"/>
        <source>Next</source>
        <translation>קדימה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="667"/>
        <source>Apply</source>
        <translation>החלה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="236"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>GRUB מותקן על ההתקן %1.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="176"/>
        <location filename="../src/gui/mainwindow.cpp" line="528"/>
        <source>Authorization Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="176"/>
        <location filename="../src/gui/mainwindow.cpp" line="529"/>
        <source>Could not obtain administrator privileges.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="211"/>
        <location filename="../src/gui/mainwindow.cpp" line="276"/>
        <location filename="../src/gui/mainwindow.cpp" line="331"/>
        <location filename="../src/gui/mainwindow.cpp" line="451"/>
        <location filename="../src/gui/mainwindow.cpp" line="672"/>
        <location filename="../src/gui/mainwindow.cpp" line="676"/>
        <location filename="../src/gui/mainwindow.cpp" line="683"/>
        <location filename="../src/gui/mainwindow.cpp" line="689"/>
        <location filename="../src/gui/mainwindow.cpp" line="697"/>
        <location filename="../src/gui/mainwindow.cpp" line="704"/>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="212"/>
        <location filename="../src/gui/mainwindow.cpp" line="277"/>
        <location filename="../src/gui/mainwindow.cpp" line="332"/>
        <source>Could not unlock %1. Please check the password and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="295"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>קובץ ההגדרות של GRUB‏ (grub.cfg) נבנה מחדש.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="346"/>
        <source>Generating initramfs images on: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="362"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="419"/>
        <source>Warning</source>
        <translation>אזהרה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="420"/>
        <source>You are going to write the content of </source>
        <translation>פעולה זו תכתוב את התוכן של</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="420"/>
        <source> to </source>
        <translation>אל</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="421"/>
        <source>

Are you sure?</source>
        <translation>

אכן ברצונך לעשות זאת?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="427"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="452"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="476"/>
        <source>Select %1 location:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <source>Back</source>
        <translation>אחורה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="521"/>
        <source>Success</source>
        <translation>הצלחה</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="521"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="546"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>התהליך הסתיים. התרחשו שגיאות.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="198"/>
        <location filename="../src/gui/mainwindow.cpp" line="263"/>
        <location filename="../src/gui/mainwindow.cpp" line="318"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="548"/>
        <source>Unknown error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="638"/>
        <source>Select GRUB location</source>
        <translation>בחירת מיקום GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="647"/>
        <source>Select initramfs options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="657"/>
        <source>Select Item to Back Up</source>
        <translation>נא לבחור פריט לגיבוי</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="662"/>
        <source>Select Item to Restore</source>
        <translation>נא לבחור פריט לשחזור</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="672"/>
        <location filename="../src/gui/mainwindow.cpp" line="683"/>
        <source>No location was selected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="677"/>
        <location filename="../src/gui/mainwindow.cpp" line="690"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="695"/>
        <source>Select backup file name</source>
        <translation>נא לבחור את שם קובץ הגיבוי</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="697"/>
        <location filename="../src/gui/mainwindow.cpp" line="704"/>
        <source>No file was selected.</source>
        <translation>לא נבחרו קבצים.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="702"/>
        <source>Select MBR or PBR backup file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="720"/>
        <source>About %1</source>
        <translation>על אודות %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="722"/>
        <source>Version: </source>
        <translation>גירסה:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="723"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="725"/>
        <source>Copyright (c) MX Linux</source>
        <translation>זכויות היוצרים (c) שמורות ל־MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="726"/>
        <source>%1 License</source>
        <translation>רישיון %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="737"/>
        <source>%1 Help</source>
        <translation>עזרה עבור %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="54"/>
        <location filename="../src/gui/about.cpp" line="59"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="116"/>
        <source>License</source>
        <translation>רישיון</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="117"/>
        <location filename="../src/gui/about.cpp" line="127"/>
        <source>Changelog</source>
        <translation>יומן שינויים</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="118"/>
        <source>Cancel</source>
        <translation>ביטול</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="31"/>
        <location filename="../src/gui/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;סגירה</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="84"/>
        <source>MX Boot Repair</source>
        <translation>תיקון האתחול של MX</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="92"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="97"/>
        <source>Force CLI mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="98"/>
        <source>Print actions without executing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Do not prompt; require flags</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Target for install: mbr, esp, root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Path for backup/restore image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Skip confirmations (for restore)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Enable verbose output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Suppress non-error output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="119"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="125"/>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="126"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>כן</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>כ</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>