<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="hi">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>एमएक्स बूट सुधार</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation>एमएक्स बूट सुधार - ESP (EFI सिस्टम विभाजन), MBR (मास्टर बूट रिकॉर्ड) या रुट विभाजन पर GRUB बूट लोड साधन पुनः इंस्टॉल करने हेतु साधन है। इसके द्वारा आप GRUB विन्यास फाइल का पुनः सृजन व MBR या PBR (रुट) को बैकअप एवं पुनः स्थापित कर सकते हैं।</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>आप क्या करना चाहेंगे?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>MBR या PBR (केवल पारंपरिक बूट) का बैकअप </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>ESP, MBR या PBR (रुट) पर बूट लोड साधन का पुनः इंस्टॉल</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>GRUB विन्यास फाइल सुधार</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>बैकअप से MBR या PBR की पुनः स्थापना (केवल पारंपरिक बूट)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="631"/>
        <source>Select Boot Method</source>
        <translation>बूट विधि चयन</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation>मास्टर बूट रिकॉर्ड</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="410"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="632"/>
        <source>Location:</source>
        <translation>स्थान :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation>EFI सिस्टम विभाजन</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation>बूट (विभाजन बूट रिकॉर्ड)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="634"/>
        <source>root</source>
        <translation>रुट</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="639"/>
        <source>Select root location:</source>
        <translation>रुट स्थान चयन :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="633"/>
        <source>Install on:</source>
        <translation>यहाँ इंस्टॉल करें :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="333"/>
        <source>Output</source>
        <translation>आउटपुट</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="401"/>
        <source>About this application</source>
        <translation>इस अनुप्रयोग के बारे में</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="404"/>
        <source>About...</source>
        <translation>बारे में...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="452"/>
        <source>Display help </source>
        <translation>सहायता देखें</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="455"/>
        <source>Help</source>
        <translation>सहायता</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="461"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="502"/>
        <source>Cancel any changes then quit</source>
        <translation>परिवर्तन रद्द कर बंद करें</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="505"/>
        <source>Cancel</source>
        <translation>रद्द करें</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="511"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="530"/>
        <source>Apply any changes</source>
        <translation>परिवर्तन लागू करें</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="533"/>
        <location filename="../src/gui/mainwindow.cpp" line="161"/>
        <source>Next</source>
        <translation>आगामी</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="667"/>
        <source>Apply</source>
        <translation>लागू करें</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="236"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>%1 उपकरण पर GRUB इंस्टॉल प्रक्रिया जारी।</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="176"/>
        <location filename="../src/gui/mainwindow.cpp" line="528"/>
        <source>Authorization Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="176"/>
        <location filename="../src/gui/mainwindow.cpp" line="529"/>
        <source>Could not obtain administrator privileges.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="211"/>
        <location filename="../src/gui/mainwindow.cpp" line="276"/>
        <location filename="../src/gui/mainwindow.cpp" line="331"/>
        <location filename="../src/gui/mainwindow.cpp" line="451"/>
        <location filename="../src/gui/mainwindow.cpp" line="672"/>
        <location filename="../src/gui/mainwindow.cpp" line="676"/>
        <location filename="../src/gui/mainwindow.cpp" line="683"/>
        <location filename="../src/gui/mainwindow.cpp" line="689"/>
        <location filename="../src/gui/mainwindow.cpp" line="697"/>
        <location filename="../src/gui/mainwindow.cpp" line="704"/>
        <source>Error</source>
        <translation>त्रुटि</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="212"/>
        <location filename="../src/gui/mainwindow.cpp" line="277"/>
        <location filename="../src/gui/mainwindow.cpp" line="332"/>
        <source>Could not unlock %1. Please check the password and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="295"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>GRUB विन्यास फाइल (grub.cfg) का पुनः सृजन जारी।</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="346"/>
        <source>Generating initramfs images on: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="362"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>%1 उपकरण से MBR या PBR का बैकअप जारी।</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="419"/>
        <source>Warning</source>
        <translation>चेतावनी</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="420"/>
        <source>You are going to write the content of </source>
        <translation>आप द्वारा यह सामग्री राइट होगी</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="420"/>
        <source> to </source>
        <translation>यहाँ पर</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="421"/>
        <source>

Are you sure?</source>
        <translation>

क्या आप निश्चित हैं?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="427"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>%1 उपकरण से MBR/PBR की पुनः स्थापना जारी।</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="452"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>सिस्टम डिस्क पर ESI सिस्टम विभाजन (ESP) हेतु खोज विफल। कृपया ESP सृजन कर पुनः प्रयास करें।</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="476"/>
        <source>Select %1 location:</source>
        <translation>%1 स्थान चुनें :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <source>Back</source>
        <translation>पीछे</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="521"/>
        <source>Success</source>
        <translation>सफलता</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="521"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation>प्रक्रिया सफलतापूर्वक पूर्ण। &lt;p&gt;&lt;b&gt;क्या आप एमएक्स बूट सुधार बंद करना चाहते हैं?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="546"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>प्रक्रिया पूर्ण। त्रुटियाँ हुई हैं।</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="198"/>
        <location filename="../src/gui/mainwindow.cpp" line="263"/>
        <location filename="../src/gui/mainwindow.cpp" line="318"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>%1 एन्क्रिप्टेड विभाजन अभिगम हेतु कूटशब्द दर्ज करें :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="548"/>
        <source>Unknown error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="638"/>
        <source>Select GRUB location</source>
        <translation>GRUB स्थान चयन</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="647"/>
        <source>Select initramfs options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="657"/>
        <source>Select Item to Back Up</source>
        <translation>बैकअप हेतु वस्तु चयन</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="662"/>
        <source>Select Item to Restore</source>
        <translation>पुनः स्थापना हेतु वस्तु चयन</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="672"/>
        <location filename="../src/gui/mainwindow.cpp" line="683"/>
        <source>No location was selected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="677"/>
        <location filename="../src/gui/mainwindow.cpp" line="690"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="695"/>
        <source>Select backup file name</source>
        <translation>बैकअप फाइल हेतु नाम चयन</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="697"/>
        <location filename="../src/gui/mainwindow.cpp" line="704"/>
        <source>No file was selected.</source>
        <translation>कोई फाइल चयनित नहीं है।</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="702"/>
        <source>Select MBR or PBR backup file</source>
        <translation>MBR या PBR बैकअप फाइल चयन</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="720"/>
        <source>About %1</source>
        <translation>%1 के बारे में</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="722"/>
        <source>Version: </source>
        <translation>संस्करण :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="723"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation>एमएक्स लिनक्स हेतु सरल बूट सुधार प्रोग्राम</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="725"/>
        <source>Copyright (c) MX Linux</source>
        <translation>कॉपीराइट (c) एमएक्स लिनक्स</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="726"/>
        <source>%1 License</source>
        <translation>%1 लाइसेंस</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="737"/>
        <source>%1 Help</source>
        <translation>%1 सहायता</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="54"/>
        <location filename="../src/gui/about.cpp" line="59"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="116"/>
        <source>License</source>
        <translation>लाइसेंस</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="117"/>
        <location filename="../src/gui/about.cpp" line="127"/>
        <source>Changelog</source>
        <translation>बदलाव सूची</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="118"/>
        <source>Cancel</source>
        <translation>रद्द करें</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="31"/>
        <location filename="../src/gui/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>बंद करें (&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="84"/>
        <source>MX Boot Repair</source>
        <translation>एमएक्स बूट सुधार</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="92"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="97"/>
        <source>Force CLI mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="98"/>
        <source>Print actions without executing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Do not prompt; require flags</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Target for install: mbr, esp, root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Path for backup/restore image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Skip confirmations (for restore)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Enable verbose output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Suppress non-error output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="119"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="125"/>
        <source>Error</source>
        <translation>त्रुटि</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="126"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>हाँ</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>ह</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>