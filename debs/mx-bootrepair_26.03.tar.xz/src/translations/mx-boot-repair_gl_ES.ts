<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="gl_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>MX Reparador do arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation>O MX Reparador do Arranque é unha ferramenta que pode ser usado para reinstalar o cargador do arranque GRUB na ESP (EFI Sistema Partition), no MBR (Master Boot Record) do disco ou no PBR da partición raíz, para reconstruír o ficheiro de configuración do GRUB, para facer copias de seguranza do MBR ou do PBR, ou para restaurar o MBR ou o PBR (root).</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>Que che gustaría facer?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>Copia de seguranza do MBR ou do PBR (só en computadores con BIOS)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>Reinstalar o cargador do arranque GRUB en ESP, MBR ou PBR (root)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>Refacer o ficheiro de configuración do GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>Restaurar MBR ou PBR a partir da copia (só en computadores con BIOS)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="441"/>
        <source>Select Boot Method</source>
        <translation>Datos para a instalación do arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation>Gravar a instalación principal</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="398"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="442"/>
        <source>Location:</source>
        <translation>Localización:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation>Partición do sistema EFI</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation> 
Raíz (Partition Boot Record)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="444"/>
        <source>root</source>
        <translation>raíz</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="449"/>
        <source>Select root location:</source>
        <translation>Seleccionar a localización da raíz:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="443"/>
        <source>Install on:</source>
        <translation>Instalar en:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="389"/>
        <source>About this application</source>
        <translation>Sobre esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="392"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="440"/>
        <source>Display help </source>
        <translation>Amosar axuda</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="443"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="449"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="490"/>
        <source>Cancel any changes then quit</source>
        <translation>Cancelar os cambios e saír</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="493"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="499"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="518"/>
        <source>Apply any changes</source>
        <translation>Aplicar cambios</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="521"/>
        <location filename="../src/gui/mainwindow.cpp" line="87"/>
        <source>Next</source>
        <translation>Seguinte</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="477"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="107"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>O GRUB está a ser instalado en %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="296"/>
        <location filename="../src/gui/mainwindow.cpp" line="366"/>
        <location filename="../src/gui/mainwindow.cpp" line="482"/>
        <location filename="../src/gui/mainwindow.cpp" line="486"/>
        <location filename="../src/gui/mainwindow.cpp" line="493"/>
        <location filename="../src/gui/mainwindow.cpp" line="499"/>
        <location filename="../src/gui/mainwindow.cpp" line="507"/>
        <location filename="../src/gui/mainwindow.cpp" line="514"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="146"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>O ficheiro de configuración do GRUB (grub.cfg) está a ser refeito.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="180"/>
        <source>Generating initramfs images on: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="209"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>Gardando o MBR/PBR de %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="265"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="266"/>
        <source>You are going to write the content of </source>
        <translation>Vai ser escrito o contido de</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="266"/>
        <source> to </source>
        <translation>en</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="267"/>
        <source>

Are you sure?</source>
        <translation>

Estás seguro?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="273"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>Restaurando o MBR/PBR en %1 a partir da copia.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="297"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>Non foi atopada calquera ESP. Crear unha partición ESP e volver a intentar.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="321"/>
        <source>Select %1 location:</source>
        <translation>Seleccionar a localización de %1:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="344"/>
        <source>Back</source>
        <translation>Volver atrás</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="360"/>
        <source>Success</source>
        <translation>Con éxito</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="360"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation>O proceso rematou con éxito.&lt;p&gt;&lt;b&gt; Saír do MX Reparador do arranque?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="366"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>O proceso rematou. Ocorreron erros.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="114"/>
        <location filename="../src/gui/mainwindow.cpp" line="154"/>
        <location filename="../src/gui/mainwindow.cpp" line="186"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Introducir o contrasinal para desbloquear a partición encriptada %1:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="448"/>
        <source>Select GRUB location</source>
        <translation>Seleccionar a localización do GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="457"/>
        <source>Select initramfs options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="467"/>
        <source>Select Item to Back Up</source>
        <translation>Seleccionar o item Facer copia de seguranza</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="472"/>
        <source>Select Item to Restore</source>
        <translation>Seleccionar o item Restaurar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="482"/>
        <location filename="../src/gui/mainwindow.cpp" line="493"/>
        <source>No location was selected.</source>
        <translation>Ningunha localización foi seleccionada.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="487"/>
        <location filename="../src/gui/mainwindow.cpp" line="500"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation>Por favor, seleccione a partición raíz do sistema que desexa arranxar.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="505"/>
        <source>Select backup file name</source>
        <translation>Escoller o nome da copia de seguranza</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="507"/>
        <location filename="../src/gui/mainwindow.cpp" line="514"/>
        <source>No file was selected.</source>
        <translation>Non foi seleccionado calquera ficheiro.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="512"/>
        <source>Select MBR or PBR backup file</source>
        <translation>Seleccionar copia de seguranza do MBR ou do PBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="530"/>
        <source>About %1</source>
        <translation>Sobre %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="532"/>
        <source>Version: </source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="533"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation>Programa simple de reparación do arranque para o MX</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="535"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="536"/>
        <source>%1 License</source>
        <translation>Licenza de %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="549"/>
        <source>%1 Help</source>
        <translation>Axuda para %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="52"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="53"/>
        <location filename="../src/gui/about.cpp" line="63"/>
        <source>Changelog</source>
        <translation>Rexistro dos cambios</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="54"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="86"/>
        <source>MX Boot Repair</source>
        <translation>MX Reparador do arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="94"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Force CLI mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Print actions without executing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Do not prompt; require flags</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Target for install: mbr, esp, root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Path for backup/restore image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Skip confirmations (for restore)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="110"/>
        <source>Enable verbose output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="111"/>
        <source>Suppress non-error output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="121"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="127"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="128"/>
        <source>You must run this program with admin access.</source>
        <translation>Debes executar este programa con acceso de administrador.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>si</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>