<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="de">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>MX Boot-Reparatur</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation>Die Bootreparatur ist ein Werkzeug zur nochmaligen Installation des GRUB Bootprogramms auf die ESP (EFI System Partition), den MBR (Master Boot Record) oder die Wurzelpartition. Das Werkzeug bietet die Möglichkeit, die GRUB Konfigurationsdatei zu rekonstruieren und den MBR oder PBR (root) zu sichern oder aus einer Sicherung wiederherzustellen. </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>Was wollen Sie tun?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>MBR oder PBR sichern (nur Legacy-Boot)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>Nochmalige Installation des GRUB Bootprogramms in ESP, MBR oder PBR (root)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>Die GRUB-Konfigurationsdatei reparieren</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation>Neugenerierung des initramfs Abbilds</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>MBR oder PBR aus Backup wieder herstellen (nur Legacy-Boot)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="585"/>
        <source>Select Boot Method</source>
        <translation>Boot-Methode auswählen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="410"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="586"/>
        <source>Location:</source>
        <translation>Ort:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation>EFI-Systempartition</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation>root (Bootsektor einer Partition)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="588"/>
        <source>root</source>
        <translation>root</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="593"/>
        <source>Select root location:</source>
        <translation>root-Speicherort auswählen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="587"/>
        <source>Install on:</source>
        <translation>Installiere auf:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="333"/>
        <source>Output</source>
        <translation>Ausgabe</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="401"/>
        <source>About this application</source>
        <translation>Über diese Anwendung</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="404"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="452"/>
        <source>Display help </source>
        <translation>Hilfe anzeigen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="455"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="461"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="502"/>
        <source>Cancel any changes then quit</source>
        <translation>Änderungen verwerfen, danach abbrechen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="505"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="511"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="530"/>
        <source>Apply any changes</source>
        <translation>Alle Änderungen übernehmen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="533"/>
        <location filename="../src/gui/mainwindow.cpp" line="140"/>
        <source>Next</source>
        <translation>Weiter</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="621"/>
        <source>Apply</source>
        <translation>Übernehmen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="214"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>GRUB wird auf Gerät %1 installiert.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="155"/>
        <location filename="../src/gui/mainwindow.cpp" line="498"/>
        <source>Authorization Failed</source>
        <translation>Authorisierung fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="155"/>
        <location filename="../src/gui/mainwindow.cpp" line="499"/>
        <source>Could not obtain administrator privileges.</source>
        <translation>Administratorrechte konnten nicht erlangt werden.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="189"/>
        <location filename="../src/gui/mainwindow.cpp" line="251"/>
        <location filename="../src/gui/mainwindow.cpp" line="303"/>
        <location filename="../src/gui/mainwindow.cpp" line="421"/>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <location filename="../src/gui/mainwindow.cpp" line="626"/>
        <location filename="../src/gui/mainwindow.cpp" line="630"/>
        <location filename="../src/gui/mainwindow.cpp" line="637"/>
        <location filename="../src/gui/mainwindow.cpp" line="643"/>
        <location filename="../src/gui/mainwindow.cpp" line="651"/>
        <location filename="../src/gui/mainwindow.cpp" line="658"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="190"/>
        <location filename="../src/gui/mainwindow.cpp" line="252"/>
        <location filename="../src/gui/mainwindow.cpp" line="304"/>
        <source>Could not unlock %1. Please check the password and try again.</source>
        <translation>%1 konnte nicht freigegeben werden. Bitte das Passwort überprüfen und erneut versuchen.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="270"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>Die  GRUB-Konfigurationsdatei (grub.cfg) wird erneuert.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="318"/>
        <source>Generating initramfs images on: %1</source>
        <translation>Generierung von initramfs Abbild auf: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="332"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>Der MBR oder PBR von Gerät %1 wird gesichert.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="389"/>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="390"/>
        <source>You are going to write the content of </source>
        <translation>Sie werden den Inhalt</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="390"/>
        <source> to </source>
        <translation>in diese Datei schreiben</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="391"/>
        <source>

Are you sure?</source>
        <translation>

Sind Sie sicher?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="397"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>MBR/PBR wird aus der Sicherung wiederhergestellt auf Gerät %1.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="422"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>Konnte keine EFI-Systempartition (ESP) auf irgendeinem Laufwerk finden. Bitte erstellen Sie eine ESP und versuchen Sie es erneut.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="446"/>
        <source>Select %1 location:</source>
        <translation>%1 Ort auswählen :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="473"/>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="491"/>
        <source>Success</source>
        <translation>Erfolg</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="491"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation>Prozess erfolgreich beendet. &lt;p&gt;&lt;b&gt;Die MX-Boot-Reparatur schliessen?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>Prozess beendet. Dabei sind Fehler aufgetreten.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="177"/>
        <location filename="../src/gui/mainwindow.cpp" line="239"/>
        <location filename="../src/gui/mainwindow.cpp" line="291"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Passwort eingeben, um verschlüsselte Partition %1 freizugeben :</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="592"/>
        <source>Select GRUB location</source>
        <translation>GRUB-Speicherort</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="601"/>
        <source>Select initramfs options</source>
        <translation>initramfs Optionen auswählen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="611"/>
        <source>Select Item to Back Up</source>
        <translation>Eintrag zur Sicherung auswählen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="616"/>
        <source>Select Item to Restore</source>
        <translation>Eintrag zum Wiederherstellen auswählen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="626"/>
        <location filename="../src/gui/mainwindow.cpp" line="637"/>
        <source>No location was selected.</source>
        <translation>Es wurde kein Speicherort ausgewählt.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="631"/>
        <location filename="../src/gui/mainwindow.cpp" line="644"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation>Bitte die root-Partition des Systems auswählen, das repariert werden soll.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="649"/>
        <source>Select backup file name</source>
        <translation>Den Backup-Dateinamen auswählen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="651"/>
        <location filename="../src/gui/mainwindow.cpp" line="658"/>
        <source>No file was selected.</source>
        <translation>Es wurde keine Datei ausgewählt.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="656"/>
        <source>Select MBR or PBR backup file</source>
        <translation>Backup-Datei MBR oder PBR auswählen</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="674"/>
        <source>About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="676"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="677"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation>Einfaches Boot-Reparatur Program für MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="679"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="680"/>
        <source>%1 License</source>
        <translation>%1 Lizenz</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="691"/>
        <source>%1 Help</source>
        <translation>%1 Hilfe</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="54"/>
        <location filename="../src/gui/about.cpp" line="59"/>
        <source>Could not load %1</source>
        <translation>%1 konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="116"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="117"/>
        <location filename="../src/gui/about.cpp" line="127"/>
        <source>Changelog</source>
        <translation>Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="118"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="96"/>
        <source>Could not load changelog.</source>
        <translation>Änderungsprotokoll konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="31"/>
        <location filename="../src/gui/about.cpp" line="134"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="84"/>
        <source>MX Boot Repair</source>
        <translation>MX-Bootreparatur</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="92"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation>MX Boot Repair - GUI und CLI Programm zur Reparatur des GRUB Bootladeprogramms</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="97"/>
        <source>Force CLI mode</source>
        <translation>CLI Modus erzwingen</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="98"/>
        <source>Print actions without executing</source>
        <translation>Aktion anzeigen ohne Ausführung</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Do not prompt; require flags</source>
        <translation>keine Eingabeaufforderung; flag erforderlich</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation>Aktion: installieren, reparieren, initramfs, backup, wiederherstellen</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Target for install: mbr, esp, root</source>
        <translation>Installationsziel: mbr, esp, root</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation>Zielgerät (z.B. sda, sda1)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation>Root Partition (z.B. /dev/sda2)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation>Partition für das Einhängen an /boot in chroot</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation>Partition für das Einhängen an /boot/efi in chroot</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Path for backup/restore image</source>
        <translation>Pfad für das Backup/Wiederherstellungs - Abbild</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Skip confirmations (for restore)</source>
        <translation>Bestätigung überspringen (für das Wiederherstellen)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Enable verbose output</source>
        <translation>ausführliche Ausgabe anfordern</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Suppress non-error output</source>
        <translation>nur Fehlermeldungen ausgeben</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="119"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation>Fehlermeldung: Optionen --verbose und --quiet schließen sich gegenseitig aus</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="125"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="126"/>
        <source>You must run this program with admin access.</source>
        <translation>Diese Anwendung muss mit Administratorrechten ausgeführt werden.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation>ungültiger Index. Nochmal versuchen:</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation>ungültige Auswahl. Ziffer eingeben</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation>MX Boot Repair (CLI)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation>1) GRUB installieren</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation>2/ GRUB reparieren (update-grub)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation>3) initramfs regenerieren</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation>4) Backup von MBR/PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation>5) Wiederherstellen von MBR/PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation>q) beenden</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation>Aktion wählen [1-5 oder &apos;q&apos; zum Beenden]:</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation>ungültige Auswahl. Eingabe von 1-5 oder &apos;q&apos; zum Beenden</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation>Ziel: 0) MBR 1) ESP 2)Root</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation>[festgestellt: UEFI]</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation>  [festgestellt: Legacy BIOS]</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation>Ziel auswählen</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation>keine Partitionen gefunden. Zurück zum Hauptmenü.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation>keine Speichermedien gefunden. Zurück zum Hauptmenü.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation>Speichermedium für MBR auswählen (z.B. sda)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation>Partition für GRUB auswählen (z.B. sda1)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation>Root-Partition des installierten Systems auswählen</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation>Root-Partion zum Reparieren auswählen</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation>Root-Partition zur initramfs Regenerierung auswählen</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation>Speichermedium auswählen von dem das MBR/PBR Backup gemacht wird</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation>Pfad für die Dateiausgabe (oder &apos;b&apos; zum Zurückspringen, &apos;q&apos; zum Beenden):</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation>Speichermedium auswählen auf das MBR/PBR wiederhergestellt wird</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation>Pfad für die Backup-Datein eingeben (oder &apos;b&apos; zum Zurückspringen, &apos;q&apos; zum Beenden):</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation>WARNUNG: die ersten 446 Bytes von /dev/ werden jetzt überschrieben</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation>weiter? [y/N]:</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>yes</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>j</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation>gestrichen</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation>unbekannte Auswahl</translation>
    </message>
</context>
</TS>