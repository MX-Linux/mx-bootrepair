<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>MX Reparar Arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation>MX Reparar Arranque es una utilidad que se puede usar para reinstalar el cargador de arranque GRUB en ESP (Partición del sistema EFI), MBR (Registro de arranque maestro) o partición raíz. Proporciona la opción de reconstruir el archivo de configuración de GRUB y hacer una copia de seguridad y restaurar MBR o PBR (raíz).</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>¿Qué desea hacer?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>Respaldo de MBR o PBR (solo arranque heredado)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>Reinstalar el cargador de arranque GRUB en ESP, MBR o PBR (root)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>Reparar archivo de configuración de GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation>Regenerar imagen initramfs</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>Restaurar MBR o PBR desde la copia de seguridad (solo arranque heredado)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="585"/>
        <source>Select Boot Method</source>
        <translation>Seleccionar metodo de arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation>Registro de arranque principal</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="410"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="586"/>
        <source>Location:</source>
        <translation>Ubicación:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation>Particion del sistema EFI</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation>Root (Registro de partición de arranque)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="588"/>
        <source>root</source>
        <translation>root</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="593"/>
        <source>Select root location:</source>
        <translation>Seleccione la ubicación de root:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="587"/>
        <source>Install on:</source>
        <translation>Instalar en:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="333"/>
        <source>Output</source>
        <translation>Salida</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="401"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="404"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="452"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="455"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="461"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="502"/>
        <source>Cancel any changes then quit</source>
        <translation>Cancelar los cambios y luego salir</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="505"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="511"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="530"/>
        <source>Apply any changes</source>
        <translation>Aplicar los cambios</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="533"/>
        <location filename="../src/gui/mainwindow.cpp" line="140"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="621"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="214"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>GRUB está siendo instalado en el dispositivo %1.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="155"/>
        <location filename="../src/gui/mainwindow.cpp" line="498"/>
        <source>Authorization Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="155"/>
        <location filename="../src/gui/mainwindow.cpp" line="499"/>
        <source>Could not obtain administrator privileges.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="189"/>
        <location filename="../src/gui/mainwindow.cpp" line="251"/>
        <location filename="../src/gui/mainwindow.cpp" line="303"/>
        <location filename="../src/gui/mainwindow.cpp" line="421"/>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <location filename="../src/gui/mainwindow.cpp" line="626"/>
        <location filename="../src/gui/mainwindow.cpp" line="630"/>
        <location filename="../src/gui/mainwindow.cpp" line="637"/>
        <location filename="../src/gui/mainwindow.cpp" line="643"/>
        <location filename="../src/gui/mainwindow.cpp" line="651"/>
        <location filename="../src/gui/mainwindow.cpp" line="658"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="190"/>
        <location filename="../src/gui/mainwindow.cpp" line="252"/>
        <location filename="../src/gui/mainwindow.cpp" line="304"/>
        <source>Could not unlock %1. Please check the password and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="270"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>El archivo de configuración de GRUB (grub.cfg) esta siendo reconstruido.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="318"/>
        <source>Generating initramfs images on: %1</source>
        <translation>Regeneración de la imagen initramfs en: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="332"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>Respaldando MBR o PBR desde el dispositivo %1.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="389"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="390"/>
        <source>You are going to write the content of </source>
        <translation>Va a escribir el contenido de </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="390"/>
        <source> to </source>
        <translation> a </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="391"/>
        <source>

Are you sure?</source>
        <translation>

¿Está seguro?</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="397"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>Restaurando MBR/PBR desde una copia de seguridad al dispositivo %1.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="422"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>No se pudo encontrar la partición de sistema EFI (ESP) en ningún disco del sistema. Por favor crear un ESP e intentar de nuevo.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="446"/>
        <source>Select %1 location:</source>
        <translation>Seleccione la ubicación de %1:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="473"/>
        <source>Back</source>
        <translation>Atras</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="491"/>
        <source>Success</source>
        <translation>Exito</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="491"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation>El Proceso terminó con exito.&lt;p&gt;&lt;b&gt;¿Desea salir de MX Reparar Arranque?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="503"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>Proceso finalizado. Ocurrieron errores.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="177"/>
        <location filename="../src/gui/mainwindow.cpp" line="239"/>
        <location filename="../src/gui/mainwindow.cpp" line="291"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Introduzca la contraseña para desbloquear la partición cifrada %1:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="592"/>
        <source>Select GRUB location</source>
        <translation>Seleccione la ubicación de GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="601"/>
        <source>Select initramfs options</source>
        <translation>Seleccionar las opciones para initramfs</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="611"/>
        <source>Select Item to Back Up</source>
        <translation>Seleccionar elemento a Respaldar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="616"/>
        <source>Select Item to Restore</source>
        <translation>Seleccionar elemento a Restaurar</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="626"/>
        <location filename="../src/gui/mainwindow.cpp" line="637"/>
        <source>No location was selected.</source>
        <translation>No se seleccionó ninguna ubicación.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="631"/>
        <location filename="../src/gui/mainwindow.cpp" line="644"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation>Seleccione la partición raíz del sistema que desea reparar.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="649"/>
        <source>Select backup file name</source>
        <translation>Seleccionar nombre del archivo de respaldo</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="651"/>
        <location filename="../src/gui/mainwindow.cpp" line="658"/>
        <source>No file was selected.</source>
        <translation>Ningún archivo fue seleccionado.</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="656"/>
        <source>Select MBR or PBR backup file</source>
        <translation>Elegir archivo de respaldo de MBR o PBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="674"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="676"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="677"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation>Programa de reparación de arranque simple para MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="679"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="680"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="693"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="53"/>
        <location filename="../src/gui/about.cpp" line="58"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="87"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="88"/>
        <location filename="../src/gui/about.cpp" line="98"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="89"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="110"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="30"/>
        <location filename="../src/gui/about.cpp" line="113"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="84"/>
        <source>MX Boot Repair</source>
        <translation>MX Reparar Arranque</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="92"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation>MX Reparar Arranque - Interfaz gráfica y línea de comandos para reparar el cargador GRUB</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="97"/>
        <source>Force CLI mode</source>
        <translation>Formar modo línea de comandos</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="98"/>
        <source>Print actions without executing</source>
        <translation>Imprimir acciones sin ejecutarlas</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Do not prompt; require flags</source>
        <translation>No preguntar, requiere indicadores</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation>Acción: instalar, reparar, initramfs, respaldar, restaurar</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Target for install: mbr, esp, root</source>
        <translation>Destino de la instalación: mbr, esp, root</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation>Dispositivo de destino (p.ej., sda, sda1)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation>Partición raíz (p.ej. /dev/sda2)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation>Partición a montar en /boot con chroot</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation>Partición a montar en /boot/efi con chroot</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Path for backup/restore image</source>
        <translation>Ruta para respaldar/restaurar imagen</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Skip confirmations (for restore)</source>
        <translation>Omitir confirmaciones (para restaurar)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Enable verbose output</source>
        <translation>Mostrar información detallada</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Suppress non-error output</source>
        <translation>Suprimir salida de información sin errores</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="119"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation>Error: las opciones --verbose y --quiet son mutuamente excluyentes
</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="125"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="126"/>
        <source>You must run this program with admin access.</source>
        <translation>Debe ejecutar este programa con acceso de administrador.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation>Índice inválido. Inténtelo de nuevo:</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation>Selección no válida. Introduzca un número</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation>MX Reparar Arranque (CLI)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation>1) Instalar GRUB</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation>2) Reparar GRUB (update-grub)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation>3) Regenerar initramfs</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation>4) Respaldar MBR/PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation>5) Restaurar MBR/PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation>q) Salir</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation>Seleccione una acción [1-5 o &quot;q&quot; para salir]:</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation>Selección no válida. Introduzca 1-5 o &quot;q&quot; para salir.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation>Objetivo: 0) MBR 1) ESP 2) Root</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation>  [detectado: UEFI]</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation>  [detectado: Legacy BIOS]</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation>Seleccionar objetivo</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation>No se han encontrado particiones. Volviendo al menú principal.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation>No se han encontrado discos. Volviendo al menú principal.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation>Seleccionar disco para MBR (p.ej. sda)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation>Seleccionar partición para GRUB (p.ej. sda1)</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation>Seleccionar la partición raíz del sistema instalado</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation>Seleccionar la partición raíz para reparar.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation>Seleccionar la partición raíz para regenerar initramfs</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation>Seleccione el disco del que desea realizar la copia de seguridad del MBR/PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation>Ruta del archivo de salida (o &quot;b&quot; para volver atrás, &quot;q&quot; para salir):</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation>Seleccione el disco al que restaurar el MBR/PBR</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation>Introduzca la ruta del archivo de copia de (o &quot;b&quot; para volver atrás, &quot;q&quot; para salir):</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation>ADVERTENCIA: Esto sobrescribirá los primeros 446 bytes de /dev/</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation>. ¿Continuar? [y/N]: </translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>sí</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation>Cancelado.</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation>Selección desconocida</translation>
    </message>
</context>
</TS>