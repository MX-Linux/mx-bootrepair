<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ja">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>MX ブートリペア</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="45"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation>MX ブートリペアは ESP (EFI システムパーティション)、MBR (マスターブートレコード)、またはルートパーティションに GRUB ブートローダを再インストールするために使用できるユーティリティです。GRUB 設定ファイルを再構築したり、MBR または PBR (root) をバックアップして復元したりするオプションを提供します。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="64"/>
        <source>What would you like to do?</source>
        <translation>どうしますか？</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="94"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>MBR・PBR のバックアップ (旧ブート形式のみ)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="70"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>GRUB ブートローダーを ESP、MBR または PBR (root)へ再インストール</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="80"/>
        <source>Repair GRUB configuration file</source>
        <translation>GRUB 設定ファイルの再構築</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="87"/>
        <source>Regenerate initramfs images</source>
        <translation>initramfs イメージを再生成する</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="101"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>MBR・PBR をバックアップから復旧 (旧ブート形式のみ)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="134"/>
        <location filename="../src/gui/mainwindow.cpp" line="441"/>
        <source>Select Boot Method</source>
        <translation>起動方法の選択</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="152"/>
        <source>Master Boot Record</source>
        <translation>MBR (マスターブートレコード)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="155"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="158"/>
        <location filename="../src/gui/mainwindow.ui" line="398"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="193"/>
        <location filename="../src/gui/mainwindow.cpp" line="442"/>
        <source>Location:</source>
        <translation>場所:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="218"/>
        <source>EFI System Partition</source>
        <translation>EFI システムパーティション</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="221"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="240"/>
        <source>Root (Partition Boot Record)</source>
        <translation>ルート (ブートレコードパーティション)</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="243"/>
        <location filename="../src/gui/mainwindow.cpp" line="444"/>
        <source>root</source>
        <translation>root</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="278"/>
        <location filename="../src/gui/mainwindow.cpp" line="449"/>
        <source>Select root location:</source>
        <translation>root の場所を選択:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="300"/>
        <location filename="../src/gui/mainwindow.cpp" line="443"/>
        <source>Install on:</source>
        <translation>インストール:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="389"/>
        <source>About this application</source>
        <translation>このアプリケーションについて</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="392"/>
        <source>About...</source>
        <translation>情報...</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="440"/>
        <source>Display help </source>
        <translation>ヘルプ表示</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="443"/>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="449"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="490"/>
        <source>Cancel any changes then quit</source>
        <translation>変更をキャンセルして終了</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="493"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="499"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="518"/>
        <source>Apply any changes</source>
        <translation>変更を適用</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.ui" line="521"/>
        <location filename="../src/gui/mainwindow.cpp" line="87"/>
        <source>Next</source>
        <translation>次へ</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="477"/>
        <source>Apply</source>
        <translation>適用</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="107"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>GRUB は %1 デバイスへインストール中です。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="296"/>
        <location filename="../src/gui/mainwindow.cpp" line="366"/>
        <location filename="../src/gui/mainwindow.cpp" line="482"/>
        <location filename="../src/gui/mainwindow.cpp" line="486"/>
        <location filename="../src/gui/mainwindow.cpp" line="493"/>
        <location filename="../src/gui/mainwindow.cpp" line="499"/>
        <location filename="../src/gui/mainwindow.cpp" line="507"/>
        <location filename="../src/gui/mainwindow.cpp" line="514"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="146"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>GRUB 設定ファイル (grub.cfg) は再構築中です。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="180"/>
        <source>Generating initramfs images on: %1</source>
        <translation>initramfs イメージを生成しています: %1</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="209"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>%1 デバイスから MBR または PBR をバックアップ中です。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="265"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="266"/>
        <source>You are going to write the content of </source>
        <translation>の内容がこれから書き込まれます:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="266"/>
        <source> to </source>
        <translation>→</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="267"/>
        <source>

Are you sure?</source>
        <translation>

よろしいですか？</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="273"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>MBR / PBR をバックアップから %1 デバイスに復元中です。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="297"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>EFI システムパーティション (ESP) がシステムディスクのどこにも見つかりません。ESP を作成しもう一度試してください。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="321"/>
        <source>Select %1 location:</source>
        <translation> %1 の場所を選んでください:</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="344"/>
        <source>Back</source>
        <translation>戻る</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="360"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="360"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation>処理が無事終了しました。&lt;p&gt;&lt;b&gt;MX ブートリペアを終了しますか？&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="366"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>処理が終了しました。エラーが発生しています。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="114"/>
        <location filename="../src/gui/mainwindow.cpp" line="154"/>
        <location filename="../src/gui/mainwindow.cpp" line="186"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>パスワードを入力し、暗号化された %1 パーティションのロックを解除してください : </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="448"/>
        <source>Select GRUB location</source>
        <translation>GRUB の場所を選んでください</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="457"/>
        <source>Select initramfs options</source>
        <translation>initramfs のオプションを選択する</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="467"/>
        <source>Select Item to Back Up</source>
        <translation>バックアップするアイテムを選択</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="472"/>
        <source>Select Item to Restore</source>
        <translation>復元するアイテムを選択</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="482"/>
        <location filename="../src/gui/mainwindow.cpp" line="493"/>
        <source>No location was selected.</source>
        <translation>場所を選択していません。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="487"/>
        <location filename="../src/gui/mainwindow.cpp" line="500"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation>これから修正しようとする root パーティションを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="505"/>
        <source>Select backup file name</source>
        <translation>バックアップファイル名を選択</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="507"/>
        <location filename="../src/gui/mainwindow.cpp" line="514"/>
        <source>No file was selected.</source>
        <translation>ファイルを選択していません。</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="512"/>
        <source>Select MBR or PBR backup file</source>
        <translation>MBR・PBR のバックアップファイルを選択</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="530"/>
        <source>About %1</source>
        <translation> %1について</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="532"/>
        <source>Version: </source>
        <translation>バージョン: </translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="533"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation>MX Linux 用のシンプルな起動修復プログラム</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="535"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="536"/>
        <source>%1 License</source>
        <translation>%1 ライセンス</translation>
    </message>
    <message>
        <location filename="../src/gui/mainwindow.cpp" line="549"/>
        <source>%1 Help</source>
        <translation>%1 のヘルプ</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/about.cpp" line="52"/>
        <source>License</source>
        <translation>ライセンス</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="53"/>
        <location filename="../src/gui/about.cpp" line="63"/>
        <source>Changelog</source>
        <translation>更新履歴</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="54"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../src/gui/about.cpp" line="73"/>
        <source>&amp;Close</source>
        <translation>閉じる(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="86"/>
        <source>MX Boot Repair</source>
        <translation>MX ブートリペア</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="94"/>
        <source>MX Boot Repair - GUI and CLI tool for repairing GRUB bootloader</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="99"/>
        <source>Force CLI mode</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="100"/>
        <source>Print actions without executing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="101"/>
        <source>Do not prompt; require flags</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="102"/>
        <source>Action: install, repair, initramfs, backup, restore</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="103"/>
        <source>Target for install: mbr, esp, root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="104"/>
        <source>Device for target (e.g., sda, sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="105"/>
        <source>Root partition (e.g., /dev/sda2)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="106"/>
        <source>Partition to mount at /boot in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="107"/>
        <source>Partition to mount at /boot/efi in chroot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="108"/>
        <source>Path for backup/restore image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="109"/>
        <source>Skip confirmations (for restore)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="110"/>
        <source>Enable verbose output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="111"/>
        <source>Suppress non-error output</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="121"/>
        <source>Error: --verbose and --quiet options are mutually exclusive
</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="127"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/gui/main.cpp" line="128"/>
        <source>You must run this program with admin access.</source>
        <translation>このプログラムは管理者権限で実行してください。</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="29"/>
        <source>Invalid index. Try again: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="48"/>
        <source>Invalid selection. Enter a number </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="234"/>
        <source>MX Boot Repair (CLI)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="235"/>
        <source>1) Install GRUB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="236"/>
        <source>2) Repair GRUB (update-grub)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="237"/>
        <source>3) Regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="238"/>
        <source>4) Backup MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="239"/>
        <source>5) Restore MBR/PBR</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="240"/>
        <source>q) Quit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="241"/>
        <source>Select action [1-5 or &apos;q&apos; to quit]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="247"/>
        <source>Invalid selection. Enter 1-5 or &apos;q&apos; to quit.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="253"/>
        <source>Target: 0) MBR  1) ESP  2) Root</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: UEFI]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="254"/>
        <source>  [detected: Legacy BIOS]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="255"/>
        <source>Select target</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="261"/>
        <location filename="../src/cli/controller.cpp" line="299"/>
        <location filename="../src/cli/controller.cpp" line="312"/>
        <source>No partitions found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="265"/>
        <location filename="../src/cli/controller.cpp" line="325"/>
        <location filename="../src/cli/controller.cpp" line="343"/>
        <source>No disks found. Returning to main menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="270"/>
        <source>Select disk for MBR (e.g., sda)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="274"/>
        <source>Select partition for GRUB (e.g., sda1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="279"/>
        <source>Select root partition of installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="300"/>
        <source>Select root partition to repair</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="313"/>
        <source>Select root partition to regenerate initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="326"/>
        <source>Select disk to back up MBR/PBR from</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="329"/>
        <source>Output file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="344"/>
        <source>Select disk to restore MBR/PBR to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="347"/>
        <source>Input backup file path (or &apos;b&apos; to go back, &apos;q&apos; to quit): </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>WARNING: This will overwrite the first 446 bytes of /dev/</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="354"/>
        <source>. Continue? [y/N]: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="357"/>
        <source>yes</source>
        <comment>confirmation input: full word</comment>
        <translation>はい</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="358"/>
        <source>y</source>
        <comment>confirmation input: single-letter yes</comment>
        <translation>はい</translation>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="362"/>
        <source>Cancelled.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cli/controller.cpp" line="369"/>
        <source>Unknown selection</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>